<template>
<div>
  <top />
  <router-view/>
</div>
</template>

<script type="text/javascript" src="https://developers.kakao.com/sdk/js/kakao.min.js"></script>

<script>
import top from "./components/Header";
export default {
  components: {
    top
  }
};
</script>

<style>
.text-center {
  text-align: center;
}
img{
  width: auto; height: auto;
  max-width: 130px;
  max-height: 130px;
}
</style>


<style lang="scss">
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
}

#nav {
  padding: 30px;

  a {
    font-weight: bold;
    color: #2c3e50;

    &.router-link-exact-active {
      color: #42b983;
    }
  }
}
</style>
