import Vue from "vue";
import Vuex from "vuex";
import http from "../http-common";
Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    accessToken: null,
    userId: "",
    userName: "",
    isLogin: false,
    image: "",
    email: "",
    map: null
  },
  getters: {
    getAccessToken(state) {
      console.log(state.accessToken);
      return state.accessToken;
    },
    getUserId(state) {
      return state.userId;
    },
    getUserName(state) {
      return state.userName;
    },
    getImage(state) {
      return state.image;
    },
    getisLogin(state) {
      return state.isLogin;
    },
    getMap (state) {
      return state.map
    },
    getEmail (state) {
      return state.email
    }
  },
  mutations: {
    LOGIN(state, payload) {
      state.accessToken = payload.token;
      state.userId = payload.userid;
      state.userName = payload.username;
      state.image = payload.image;
      state.isLogin = true;
      state.email = payload.email;
      console.log("id : " + state.email);
    },
    LOGOUT(state) {
      state.accessToken = null;
      state.userId = "";
      state.userName = "";
      state.isLogin = false;
      state.image = "";
      state.email = "";
    },
    changeMap (state, newMap) {
      state.map = newMap
    }
  },
  actions: {
    LOGOUT(context) {
      context.commit("LOGOUT");
      http.defaults.headers.common["auth-token"] = undefined;
    },
    callMap({ commit }, newMap) {
      commit('changeMap', newMap)
    }
  },
  modules: {}
});