import Vue from 'vue';
import Vuex from 'vuex';

Vue.use(Vuex);

export default new Vuex.Store({
  state: {
    map: null
  },
  actions: {
    callMap({ commit }, newMap) {
      commit('changeMap', newMap)
    }
  },
  mutations: {
    changeMap (state, newMap) {
      state.map = newMap
    }
  },
  getters: {
    getMap (state) {
      return state.map
    }
  },
});