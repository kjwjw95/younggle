import '@babel/polyfill'
import 'mutationobserver-shim'
import Vue from "vue";
import './plugins/bootstrap-vue'
import App from "./App.vue";
import router from './router'
import BootstrapVue from 'bootstrap-vue'
import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap-vue/dist/bootstrap-vue.css'
import store from "./store";
import VModal from 'vue-js-modal'
Vue.use(VModal, { dynamic: true })
Vue.use(BootstrapVue)
Vue.config.productionTip = false;
window.Kakao.init("b3c7b727d804a4c6b7dab6d378846a77");
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount("#app");
