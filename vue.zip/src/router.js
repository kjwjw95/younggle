import Vue from "vue";
import Router from "vue-router";
import HouseDeal from "./components/HouseDeal.vue";
import Callback from "./components/member/callback.vue";

import HouseRegister from "./components/house/House_register.vue";
import Notice from "./components/notice/Notice.vue";
import NoticeList from "./components/notice/NoticeList.vue";
import MainPage from "./components/MainPage.vue";
import NoticeWrite from "./components/notice/NoticeWrite.vue";
import NoticeDetail from "./components/notice/NoticeDetail.vue";
import NoticeModify from "./components/notice/NoticeModify.vue";
import Question from "./components/question/Question.vue";
import QuestionList from "./components/question/QuestionList.vue";
import QuestionWrite from "./components/question/QuestionWrite.vue";
import QuestionDetail from "./components/question/QuestionDetail.vue";
import MyHouseList from "./components/house/MyHouseList.vue";
import HouseDetail from "./components/house/HouseDetail.vue";
import HouseModify from "./components/house/HouseModify.vue";
import House from "./components/house/House.vue";
import HouseList from "./components/house/HouseList.vue";
import MyChoiceList from "./components/house/MyChoiceList.vue";
import MyChoiceList2 from "./components/house/MyChoiceList2.vue";
import ReservList from "./components/house/ReservList.vue";
Vue.use(Router);

export default new Router({
  mode: "history",
  routes: [
    {
      path: "/",
      name: "MainPage",
      alias: "MainPage",
      component: MainPage
    },
    {
      path: '/housedeal/',
      name: 'housedeal',
      component: HouseDeal,
      props: true,
    },
    {
      path: '/callback',
      name: 'callback',
      component: Callback,
      props: true,
    },
    {
      path: "/houseregister",
      name: "HouseRegister",
      component: HouseRegister,
    },
    {
      path: "/notice",
      name: "Notice",
      component: Notice,
      children: [
        {
          path: '/noticelist',
          component: NoticeList
        }
      ]
    },
    {
      path: "/notice/write",
      name: "NoticeWrite",
      component: NoticeWrite
    },
    {
      path: "/notice/:no",
      name: "NoticeDetail",
      component: NoticeDetail,
      props: true,
    },
    {
      path: "/notice/modify/:no",
      name: "NoticeModify",
      component: NoticeModify,
      props: true,
    },
    {
      path: "/question/write",
      name: "QuestionWrite",
      component: QuestionWrite,
    },
    {
      path: "/question",
      name: "Question",
      component: Question,
      children: [
        {
          path: '/questionlist',
          component: QuestionList
        }
      ]
    },
    {
      path: "/question/:no",
      name: "QuestionDetail",
      component: QuestionDetail,
      props: true,
    },
    {
      path: "/myhouselist",
      name: "MyHouseList",
      component: MyHouseList
    },
    {
      path: "/house/:no",
      name: "HouseDetail",
      component: HouseDetail,
      props: true,
    },
    {
      path: "/house/modify/:no",
      name: "HouseModify",
      component: HouseModify,
      props: true,
    },
    {
      path: "/house",
      name: "House",
      component: House,
      children:[
        {
          path: '/houselist',
          component: HouseList,
        }
      ]
    },
    {
      path: "/mychoicelist",
      name: "MyChoiceList",
      component: MyChoiceList
    },
    {
      path: "/mychoicelist2",
      name: "MyChoiceList2",
      component: MyChoiceList2
    },
    {
      path: "/reservlist",
      name: "ReservList",
      component: ReservList
    }
  ]
});