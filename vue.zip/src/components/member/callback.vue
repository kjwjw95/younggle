<template>
  <div></div>
</template>
<script type="text/javascript" src="https://developers.kakao.com/sdk/js/kakao.min.js"></script>

<script>
import axios from "axios";
export default {
  data() {
    return {
      token: "",
      userid: "",
      username: "",
      image: "",
      email: "",
    };
  },
  mounted() {
    const qs = require("qs");
    let accessToken = null;
    const parameter = {
      grant_type: "authorization_code",
      client_id: "b3c7b727d804a4c6b7dab6d378846a77",
      code: this.$route.query.code,
    };
    axios
      .post("https://kauth.kakao.com/oauth/token", qs.stringify(parameter), {
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
        },
      })
      .then((res) => {
        accessToken = res.data.access_token;
        console.log(accessToken);
        console.log(JSON.stringify(res));
        this.$store.state.accessToken = accessToken;
        this.$store.state.isLogin = true;
        console.log(this.$store.state.isLogin);
        Kakao.Auth.setAccessToken(accessToken);
        this.Set(accessToken);
        this.$router.push({
          name: "MainPage"
        });
        
      });
  },
  methods: {
    Save() {
      console.log("save"+this.userid);
      this.$store.commit("LOGIN", {
        token: this.token,
        userid: this.userid,
        username: this.username,
        image: this.image,
        email: this.email
      });
    },
    Set(accessToken) {
      Kakao.API.request({
        url: "/v2/user/me",
        success: (response) => {
          console.log(response.kakao_account.profile.nickname);
          this.token=accessToken;
          this.userid=response.id;
          this.username=response.kakao_account.profile.nickname;
          this.image=response.kakao_account.profile.profile_image_url;
          this.email=response.kakao_account.email;
          this.Save();
        },
        fail: function (error) {
          console.log(error);
        },
      });
    },
  }
};
</script>