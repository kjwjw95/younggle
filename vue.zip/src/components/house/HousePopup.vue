<template>
    <div class="container">
        <div style="text-align:center;">
            <br>
            <h5>방문예약 날짜</h5>
            <input style="width:100%" type="date" id="date" name="date" v-model="date" class="form-control" placeholder="입주 가능일 입력" required>
            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="reservation">예약</button>
            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="cancel">취소</button>
        </div>
    </div>
</template>
<script>
import { mapGetters } from "vuex";
import http from "../../http-common";

export default {
    name: 'dynamic-modal',
    props : ['no'],
    data() {
        return {
            del_password: '',
            date: "",
        }
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods : {
        reservation() {
            if(this.date==""){
                alert("방문예약 날짜를 선택해주세요.");
                return;
            }
            http
            .post("/house/reservation", {
                id: this.getUserId,
                no: this.no,
                date: this.date
            })
            .then((success) => {
                console.log(success);
                this.$emit('close')
            })
        },
        cancel() {
            this.$emit('close')
        }
    }
}
</script>
<style scoped>
button {
  margin: 10px;
}
h5 {
  font-weight: 550;
}
</style>
