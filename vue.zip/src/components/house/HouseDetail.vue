<template>
  <div id="tab" class="container-fluid">
    <div class="d-flex align-items-center py-5">
      <div class="container">
        <div class="row">
          <div style="line-height: 50%" class="col-lg-10 mx-auto">
            <h2 class="login-heading mb-4">매물 정보</h2>
            <h5>{{ canSave }}</h5>
            <br />
            <h5>판매자정보</h5>
            <p style="float: right">글 작성일: {{ house.regiDate }}</p>
            <br />
            <br />
            <table style="width: 100%">
              <input
                type="text"
                id="id"
                name="id"
                class="form-control"
                v-model="house.id"
                required
                readonly
              />
            </table>
            <br />
            <table style="width: 100%">
              <input
                type="tel"
                id="tel"
                name="tel"
                class="form-control"
                v-model="house.tel"
                required
                readonly
              />
            </table>
            <br />
            <br />
            <br />

            <h5>매물정보</h5>
            <table style="width: 100%; text-align: center">
              <tr>
                <th>매매 유형</th>
                <th>매물 종류</th>
              </tr>
              <br />
              <tr>
                <th>
                  <input
                    type="text"
                    id="type"
                    name="type"
                    v-model="house.type"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="houseType"
                    name="houseType"
                    v-model="house.houseType"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
              <br />
            </table>
            <table style="width: 100%; text-align: center">
              <tr>
                <th style="width: 15%">우편변호</th>
                <th style="width: 45%">주소</th>
                <th style="width: 40%">나머지 주소 입력</th>
              </tr>
              <br />
              <tr>
                <th>
                  <input
                    type="text"
                    id="postCode"
                    name="postCode"
                    v-model="house.postCode"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="addr"
                    name="addr"
                    v-model="house.addr"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="addAddr"
                    name="addAddr"
                    v-model="house.addAddr"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
              <br />
            </table>
            <table style="width: 100%; text-align: center">
              <tr>
                <th style="width: 15%">층수</th>
                <th style="width: 15%">면적</th>
                <th style="width: 15%">방향</th>
                <th style="width: 15%">방 개수</th>
                <th style="width: 20%">욕실 개수</th>
                <th style="width: 20%">준공 년월</th>
              </tr>
              <br />
              <tr>
                <th>
                  <input
                    type="text"
                    id="layer"
                    name="layer"
                    v-model="house.layer"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="area"
                    name="area"
                    v-model="house.area"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="direction"
                    name="direction"
                    v-model="house.direction"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="room"
                    name="room"
                    v-model="house.room"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="bathroom"
                    name="bathroom"
                    v-model="house.bathroom"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="yearMonth"
                    name="yearMonth"
                    v-model="house.yearMonth"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
              <br />
            </table>
            <table style="width: 100%">
              <tr>
                <th style="text-align: center">
                  매물 특징(부대시설/교통/주변시설 등)
                </th>
              </tr>
              <br />
              <tr>
                <th>
                  <textarea
                    class="form-control"
                    style="width: 100%"
                    v-model="house.addValue"
                    id="addValue"
                    name="addValue"
                    required
                    readonly
                  ></textarea>
                </th>
              </tr>
              <br />
            </table>
            <br />
            <br />
            <input
              type="text"
              id="dongCode"
              name="dongCode"
              style="display: none"
            />

            <h5>거래조건</h5>
            <table style="line-height: 60%; width: 100%; text-align: center">
              <tr v-if="house.type === '매매'" v-cloak>
                <th style="width: 70%">매매가</th>
                <th style="width: 30%">융자</th>
              </tr>
              <tr v-if="house.type === '전세'" v-cloak>
                <th style="width: 70%">전세가</th>
                <th style="width: 30%">융자</th>
              </tr>
              <tr v-if="house.type === '월세'" v-cloak>
                <th style="width: 35%">보증금</th>
                <th style="width: 35%">월세</th>
                <th style="width: 30%">융자</th>
              </tr>
              <br />
              <tr v-if="house.type === '매매'" v-cloak>
                <th>
                  <input
                    type="text"
                    id="price"
                    name="price"
                    v-model="house.price"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="tel"
                    id="financing"
                    name="financing"
                    v-model="house.financing"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
              <tr v-if="house.type === '전세'" v-cloak>
                <th>
                  <input
                    type="text"
                    id="price"
                    name="price"
                    v-model="house.price"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="tel"
                    id="financing"
                    name="financing"
                    v-model="house.financing"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
              <tr v-if="house.type === '월세'" v-cloak>
                <th>
                  <input
                    type="text"
                    id="price"
                    name="price"
                    v-model="house.price"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="monthPrice"
                    name="monthPrice"
                    v-model="house.monthPrice"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    type="tel"
                    id="financing"
                    name="financing"
                    v-model="house.financing"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
            </table>
            <br />
            <table style="line-height: 70%; width: 100%; text-align: center">
              <tr>
                <th style="width: 70%">입주 가능일</th>
                <th style="width: 30%">가격조정 가능 여부</th>
              </tr>
              <br />
              <tr>
                <th>
                  <input
                    type="text"
                    id="date"
                    name="date"
                    v-model="house.date"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th>
                  <input
                    style="display: inline-block; width: 20px"
                    id="deal"
                    type="checkbox"
                    class="form-control"
                    name="deal"
                    v-model="house.deal"
                    true-value="1"
                    false-value="0"
                    onclick="return false;"
                  />
                </th>
              </tr>
              <br />
            </table>

            <br />
            <h5>
              {{ year }}년 {{ month }}월 기준 평균 이율 :
              {{ loan.interestRate }}%
            </h5>
            <br />
            <table style="line-height: 60%; width: 100%; text-align: center">
              <tr>
                <th style="width: 20%">대출 종류</th>
                <th style="width: 10%">대출 비율</th>
                <th style="width: 20%">상환 방법</th>
                <th style="width: 15%">대출 기간(년)</th>
                <th style="width: auto">총이자</th>
                <th v-if="loan.repay == '원리금 균등상환'" style="width: 15%">
                  {{ loan.month }}
                </th>
              </tr>
              <br />
              <tr>
                <th>
                  <select
                    v-model="loan.loantype"
                    name="type"
                    class="form-control"
                    style="float: left"
                    @change="findRatio"
                  >
                    <option disabled value="">--대출 유형--</option>
                    <option>기업대출</option>
                    <option>대기업대출</option>
                    <option>중소기업대출</option>
                    <option>가계대출</option>
                    <option>주택담보대출</option>
                    <option>일반신용대출</option>
                  </select>
                </th>
                <th>
                  <input
                    type="text"
                    id="loanratio"
                    name="loanratio"
                    v-model="loan.ratio"
                    @change="ratioChange"
                    @click="ratioClick"
                    class="form-control"
                  />
                </th>
                <th>
                  <select
                    v-model="loan.repay"
                    name="type"
                    class="form-control"
                    style="float: left"
                  >
                    <option disabled value="">--상환 방법--</option>
                    <option>원리금 균등상환</option>
                    <option>원금 균등상환</option>
                    <option>원금 만기일시상환</option>
                  </select>
                </th>
                <th>
                  <input
                    type="number"
                    id="loanterm"
                    name="loanterm"
                    v-model="loan.term"
                    class="form-control"
                  />
                </th>
                <th>
                  <input
                    type="text"
                    id="interest"
                    name="interest"
                    v-model="loan.interest"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
                <th v-if="loan.repay == '원리금 균등상환'">
                  <input
                    type="text"
                    id="monthInter"
                    name="monthInter"
                    v-model="loan.monthInter"
                    class="form-control"
                    required
                    readonly
                  />
                </th>
              </tr>
            </table>

            <br />
            <div style="text-align: center">
              <button
                v-if="getUserId != house.id && getisLogin"
                id="allowEdit"
                class="btn btn-primary font-weight-bold"
                type="button"
                v-on:click="doc_del_rendar"
              >
                예약
              </button>
              <button
                v-if="getUserId == house.id"
                id="allowEdit"
                class="btn btn-primary font-weight-bold"
                type="button"
                v-on:click="modifyHouse"
              >
                수정
              </button>
              <!-- 어드민 설정 -->
              <button
                v-if="getUserId == '1541781079' || getUserId == house.id"
                id="allowEdit"
                class="btn btn-primary font-weight-bold"
                type="button"
                v-on:click="deleteHouse"
              >
                삭제
              </button>
              <button
                id="allowEdit"
                class="btn btn-primary font-weight-bold"
                type="button"
                v-on:click="back"
              >
                목록
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<script>
import { mapGetters } from "vuex";
import http from "../../http-common";
import DelPopup from './HousePopup.vue';
import Axios from 'axios';
export default {
    name: 'HouseDetail',
    props: ["no"],
    data() {
        return {
            house: {},
            loan:{
                loantype: "",
                ratio: "",
                repay: "",
                interest: "",
                month: "월별 상환금",
                monthInter: "",
                interestRate: "",
                term: ""
            },
            year:"2020",
            month:"05",
            interest:[],
            canSave:""
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        show_init: function() {
            http
            .get("/house/" + this.no)
            .then(response => {
                this.house = response.data;
                this.cansaveCalcul();
                })
            .catch(() => {
                this.errored = true;
            })
            .finally(() => (this.loading = false));
        },
        back: function() {
            this.$router.go(-1);
        },
        deleteHouse: function() {
            http
            .delete("/house/" + this.no)
            .then((success) => {
                console.log(success);
                this.$router.go(-1);
            })
        },
        modifyHouse: function() {
            this.$router.push("/house/modify/" + this.no);
        },
        doc_del_rendar(){
            this.$modal.show(DelPopup,{
                no : this.house.no,
                modal : this.$modal },{
                    name: 'dynamic-modal',
                    width : '330px',
                    height : '160px',
                    draggable: true,
            })
        },
        ratioChange() {
            if(this.loan.ratio>=70){
                alert("대출은 집값의 70%를 넘어갈 수 없습니다.");
                this.loan.ratio="";
                document.getElementById('loanratio').focus();
            }else if(this.loan.ratio<0){
                alert("대출은 음수를 입력할 수 없습니다.");
                this.loan.ratio="";
                document.getElementById('loanratio').focus();
            }else if(!isNaN(this.loan.ratio)){
                if(this.loan.ratio.length==1)
                    this.loan.ratio="0"+this.loan.ratio;
                this.loan.ratio+="%";
            }else{
                this.loan.ratio="";
                document.getElementById('loanratio').focus();
            }
        },
        ratioClick() {
                this.loan.ratio="";
        },
        LoadInter() {
            var Key="8c492a38ad2a4fd99f416528983bfcf5";
            var link="https://www.hf.go.kr/research/openapi/SttsApiTblData.do?KEY="+Key+"&Type=json&pIndex=1&pSize=100&STATBL_ID=T189923126972824&DTACYCLE_CD=MM&WRTTIME_IDTFR_ID=202005"
            Axios
            .get(link).then(res=>{
                this.interest=res.data.SttsApiTblData[1].row;
            });
        },
        findRatio() {
            for(var i=1; i<this.interest.length;i++){
                if(this.interest[i].ITM_NM == this.loan.loantype){
                    this.loan.interestRate=this.interest[i].DTA_VAL;
                    break;
                }
            }
        },
        cansaveCalcul() {
            var pr=this.house.price;
            let save=0;
            console.log(pr);
            if(pr<5000){
                save=Math.min(pr*0.006,25);
            }else if(pr>=5000 && pr<20000){
                save=Math.min(pr*0.005,80);
            }else if(pr>=20000 && pr<60000){
                save=pr*0.004;
            }else if(pr>=60000 && pr<90000){
                save=pr*0.005;
            }else if(pr>=90000){
                save=pr*0.009;
            }
            console.log
            this.canSave=save+"만원의 중개 수수료를 절약할 수 있습니다.";
        }
    },
    mounted() {
        this.show_init();
        this.LoadInter();
        
    },
    watch: {
        loan: {
            deep: true,
            handler(data){
                // console.log(this.loan.ratio.length+" "+this.loan.repay.length+" "+this.loan.interestRate+this.loan.term.length);
                if(this.loan.ratio && this.loan.repay && this.loan.interestRate && this.loan.term){
 
                    let A=this.house.price*this.loan.ratio.substr(0,2)*100; //원금
                    let R=this.loan.interestRate/1200;  //비율
                    let n=this.loan.term*12;    //개월수
                    console.log(A+" "+R+" "+n+" "+this.loan.repay);
                    if(this.loan.repay=="원리금 균등상환"){
                        this.loan.monthInter=Math.round(A*R*Math.pow((1+R),n)/(Math.pow((1+R),n)-1));
                        this.loan.interest=this.loan.monthInter*n-A;
                        // this.loan.monthInter+="원";
                        // this.loan.interest+="원";
                    }else if(this.loan.repay=="원금 균등상환"){

                        var sum = 0;
      
                            for(var i = 0; i<n; i++) {
                                sum += (A-A*i/n)*R;
                            }
                        this.loan.interest=sum;
                    }else if(this.loan.repay=="원금 만기일시상환"){
                        this.loan.monthInter=Math.round(A*R);
                        this.loan.interest=this.loan.monthInter*n;
                    }
                }
            }
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
button {
  margin: 10px;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>