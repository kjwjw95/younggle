<template>
  <div class="about">
    <router-view/>
    <!-- <house-list/> -->
  </div>
</template>

<script>
export default {
  name: "House",
  components: {
    // HouseList
  },
    mounted() {
        this.$router.push('houselist?no=' + 10);
    },
};
</script>