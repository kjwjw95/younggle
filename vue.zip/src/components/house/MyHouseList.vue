<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">내 매물 목록</h2>
                        <table style="width: 100%" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th style="width:15%; text-align:center;">매매 유형</th>
                                    <th style="width:15%; text-align:center;">매물 종류</th>
                                    <th style="width:35%; text-align:center;">지역</th>
                                    <th style="width:35%; text-align:center;">상세 주소</th>
                                </tr>
                            </thead>
                            <tbody v-if="(houses != null)" id = "searchResult">
                                <tr v-for="(house,index) in houses" class="houses" data-status="active" v-bind:key="index">
                                    <td id="type" style="text-align:center;" v-on:click="detail(house.no)">{{house.type}}</td>
                                    <td id="houseType" style="text-align:center;" v-on:click="detail(house.no)">{{house.houseType}}</td>
                                    <td id="addr" v-on:click="detail(house.no)">{{house.addr}}</td>
                                    <td id="addAddr" v-on:click="detail(house.no)">{{house.addAddr}}</td>
                                </tr>
                            </tbody>
                            <h4 v-else-if="(houses == null)">판매중인 매물이 없습니다.</h4>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";
import { mapGetters } from "vuex";

export default {
    name: 'MyHouseList',
    data() {
        return {
            loading: true,
            errored: false,
            houses: []
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        detail: function(no) {
            this.$router.push("/house/" + no);
        },
    },
    created() {
        if(!this.getisLogin){
            alert("나의 매물 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            http
            .get("/house/myList/" + this.getUserId)
            .then(response => (this.houses = response.data))
            .catch(() => {
                this.errored = true;
            })
            .finally(() => (this.loading = false));
        }
    }
}
</script>

<style scoped>
#top {
    font-weight: 500;
    color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
