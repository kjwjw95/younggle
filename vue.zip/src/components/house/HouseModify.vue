<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div style="line-height:50%" class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">매물 수정</h2>

                        <h5>판매자정보</h5>
                        <table style="width: 100%">
                            <input type="text" id="id" name="id" class="form-control" v-model="house.id" required readonly>
                        </table>
                        <br>
                        <table style="width: 100%">
                            <input type="tel" id="tel" name="tel" class="form-control" v-model="house.tel" placeholder="전화번호" required>
                        </table>
                        <br>
                        <br>
                        <br>

                        <h5>매물정보</h5>
                        
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th>
                                    매매 유형
                                </th>
                                <th>
                                    매물 종류
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <select v-model="house.type" name="type" class="form-control" style="float:left;">
                                        <option value="" selected disabled hidden>--매매 유형--</option>
                                        <option value="매매">매매</option>
                                        <option value="전세">전세</option>
                                        <option value="월세">월세</option>
                                    </select>
                                </th>
                                <th>
                                    <select v-model="house.houseType" name="houseType" class="form-control" style="float:left;">
                                        <option value="" selected disabled hidden>--매물 종류--</option>
                                        <option value="아파트">아파트</option>
                                        <option value="오피스텔">오피스텔</option>
                                        <option value="빌라">빌라</option>
                                    </select>
                                </th>
                                <th>
                                    <button v-on:click="post_search" class="form-control">주소 검색</button>
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th style="width:15%;">
                                    우편변호
                                </th>
                                <th style="width:45%;">
                                    주소
                                </th>
                                <th style="width:40%;">
                                    나머지 주소 입력
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="text" id="postCode" name="postCode" placeholder="우편번호 검색" class="form-control" required readonly>
                                </th>
                                <th>
                                    <input type="text" id="addr" name="addr" placeholder="주소 검색" class="form-control" required readonly>
                                </th>
                                <th>
                                    <input type="text" id="addAddr" name="addAddr" placeholder="추가 주소를 입력해 주세요" v-model="house.addAddr" class="form-control" required>
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th style="width:15%;">
                                    층수
                                </th>
                                <th style="width:15%;">
                                    면적
                                </th>
                                <th style="width:15%;">
                                    방향
                                </th>
                                <th style="width:15%;">
                                    방 개수
                                </th>
                                <th style="width:20%;">
                                    욕실 개수
                                </th>
                                <th style="width:20%;">
                                    준공 년월
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="text" id="layer" name="layer" v-model="house.layer" class="form-control" placeholder="층수 입력">
                                </th>
                                <th>
                                    <input type="text" id="area" name="area" v-model="house.area" class="form-control" placeholder="면적 입력">
                                </th>
                                <th>
                                    <input type="text" id="direction" name="direction" v-model="house.direction" class="form-control" placeholder="방향 입력">
                                </th>
                                <th>
                                    <input type="text" id="room" name="room" v-model="house.room" class="form-control" placeholder="방의 개수 입력">
                                </th>
                                <th>
                                    <input type="text" id="bathroom" name="bathroom" v-model="house.bathroom" class="form-control" placeholder="욕실 개수 입력">
                                </th>
                                <th>
                                    <input type="text" id="yearMonth" name="yearMonth" v-model="house.yearMonth" class="form-control" placeholder="준공 년월 입력">
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%">
                            <tr>
                                <th style="text-align:center;">
                                    매물 특징(부대시설/교통/주변시설 등)
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <textarea class="form-control" style="width:100%;" v-model="house.addValue" id="addValue" name="addValue"></textarea>
                                </th>
                            </tr>
                            <br>
                        </table>
                        <div id="imp">*층수, 면적, 방수, 욕실개수는 숫자만 입력 해주세요</div>
                        <br>
                        <br>
                        <input type="text" id="dongCode" name="dongCode" style="display:none;">

                        <h5>거래조건</h5>
                        <table style="line-height:60%; width: 100%; text-align:center">
                            <tr v-if="house.type==='매매'" v-cloak>
                                <th style="width:70%;">
                                    매매가(만원 단위)
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <tr v-if="house.type==='전세'" v-cloak>
                                <th style="width:70%;">
                                    전세가
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <tr v-if="house.type==='월세'" v-cloak>
                                <th style="width:35%;">
                                    보증금
                                </th>
                                <th style="width:35%;">
                                    월세
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <br>
                            <tr v-if="house.type==='매매'" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="house.price" class="form-control" placeholder="매매가 입력" required>
                                </th>
                                <th>
                                    <input type="tel" id="financing" name="financing" v-model="house.financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                            <tr v-if="house.type==='전세'" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="house.price" class="form-control" placeholder="전세가 입력" required>
                                </th>
                                <th>
                                    <input type="tel" id="financing" name="financing" v-model="house.financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                            <tr v-if="house.type==='월세'" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="house.price" class="form-control" placeholder="보증금 입력" required>
                                </th>
                                <th>
                                    <input type="text" id="monthPrice" name="monthPrice" v-model="house.monthPrice" class="form-control" placeholder="월세 입력" required>
                                </th>
                                <th>
                                    <input type="tel" id="financing" name="financing" v-model="house.financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                        </table>
                        <br>
                        <table style="line-height:70%; width: 100%; text-align:center;">
                            <tr>
                                <th style="width:70%;">
                                    입주 가능일
                                </th>
                                <th style="width:30%;">
                                    가격조정 가능 여부
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="date" id="date" name="date" v-model="house.date" class="form-control" placeholder="입주 가능일 입력" required>
                                </th>
                                <th>
                                    <input style="display:inline-block; width:20px; left:100px" id="deal" type="checkbox" class="form-control" name="deal" v-model="house.deal" true-value="1" false-value="0">
                                </th>
                            </tr>
                            <br>
                        </table>
                        <br>
                        <div style="text-align: center;">
                            <button id="allowEdit" class="btn btn-primary font-weight-bold mb-2 col-5 mr-1" type="button" v-on:click="modifyHouse">수정 완료</button>
                            <button id="allowEdit" class="btn btn-primary font-weight-bold mb-2 col-5 mr-1" type="button" v-on:click="back">취소</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<script>
import { mapGetters } from "vuex";
import http from "../../http-common";

export default {
    name: 'HouseDetail',
    props: ["no"],
    data() {
        return {
            house: {}
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        post_search: function() {
            
            new daum.Postcode({
                oncomplete(data) {
                    var ad = '';

                    if(data.userSelectedType==='R'){
                        ad = data.roadAddress;
                    } else {
                        ad = data.jibunAddress;
                    }

                    document.getElementById('addr').value = ad;
                    document.getElementById('postCode').value = data.zonecode;
                    document.getElementById('dongCode').value = data.bcode;
                }
            }).open()
        },
        show_init: function() {
            http
            .get("/house/" + this.no)
            .then(response => {
                this.house = response.data
                document.getElementById('addr').value = this.house.addr;
                document.getElementById('postCode').value = this.house.postCode;
                document.getElementById('dongCode').value = this.house.dongCode;
            })
            .catch(() => {
                this.errored = true;
            })
            .finally(() => (this.loading = false));
        },
        modifyHouse: function() {
            this.house.postCode=document.getElementById('postCode').value;
            this.house.dongCode=document.getElementById('dongCode').value;
            this.house.addr=document.getElementById('addr').value;

            if (this.house.tel == ""){
                alert("전화번호를 입력하세요.");
                return;
            }
            if (this.house.type == "") {
                alert("거래 방법을 선택하세요.");
                return;
            }
            if (this.house.houseType == "") {
                alert("거래할 집 종류를 선택하세요.");
                return;
            }
            if (this.house.postCode == "") {
                alert("주소를 검색하세요.");
                return;
            }
            if (this.house.addAddr == "") {
                alert("상세 주소를 입력하세요.");
                return;
            }
            if (this.house.price == "") {
                alert("거래 가격을 입력하세요.");
                return;
            }
            if (this.house.monthPrice == "" && this.type == "월세") {
                alert("월세를 입력하세요.");
                return;
            }
            if (this.house.date == null) {
                alert("입주가능일을 선택하세요.");
                return;
            }

            http
            .put("/house/", {
                no: this.house.no,
                id: this.house.id,
                tel: this.house.tel,
                type: this.house.type,
                houseType: this.house.houseType,
                postCode: this.house.postCode,
                dongCode: this.house.dongCode,
                addr: this.house.addr,
                addAddr: this.house.addAddr,
                layer: this.house.layer,
                area: this.house.area,
                direction: this.house.direction,
                room: this.house.room,
                bathroom: this.house.bathroom,
                yearMonth: this.house.yearMonth,
                addValue: this.house.addValue,
                price: this.house.price,
                monthPrice: this.house.monthPrice,
                financing: this.house.financing,
                date: this.house.date,
                deal: this.house.deal
            })
            .then((success) => {
                console.log(success);
                this.$router.go(-1);
                })
        },
        back: function() {
            this.$router.go(-1);
        }
    },
    mounted() {
        if(!this.getisLogin){
            alert("매물 수정 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            this.show_init();
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#imp {
    font-size: 10px;
    text-align: right;
    color: red;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
