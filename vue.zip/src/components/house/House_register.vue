<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div style="line-height:50%" class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">매물 등록</h2>

                        <h5>판매자정보</h5>
                        <table style="width: 100%">
                            <input type="text" id="id" name="id" class="form-control" v-model="id" required readonly>
                        </table>
                        <br>
                        <table style="width: 100%">
                            <input type="tel" id="tel" name="tel" class="form-control" v-model="tel" placeholder="전화번호" required>
                        </table>
                        <br>
                        <br>
                        <br>

                        <h5>매물정보</h5>
                        
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th>
                                    매매 유형
                                </th>
                                <th>
                                    매물 종류
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <select v-model="type" name="type" class="form-control" style="float:left;">
                                        <option value="" selected disabled hidden>--매매 유형--</option>
                                        <option value="매매">매매</option>
                                        <option value="전세">전세</option>
                                        <option value="월세">월세</option>
                                    </select>
                                </th>
                                <th>
                                    <select v-model="houseType" name="houseType" class="form-control" style="float:left;">
                                        <option value="" selected disabled hidden>--매물 종류--</option>
                                        <option value="아파트">아파트</option>
                                        <option value="오피스텔">오피스텔</option>
                                        <option value="빌라">빌라</option>
                                    </select>
                                </th>
                                <th>
                                    <button v-on:click="post_search" class="form-control">주소 검색</button>
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th style="width:15%;">
                                    우편변호
                                </th>
                                <th style="width:45%;">
                                    주소
                                </th>
                                <th style="width:40%;">
                                    나머지 주소 입력
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="text" id="postCode" name="postCode" placeholder="우편번호 검색" class="form-control" required readonly>
                                </th>
                                <th>
                                    <input type="text" id="addr" name="addr" placeholder="주소 검색" class="form-control" required readonly>
                                </th>
                                <th>
                                    <input type="text" id="addAddr" name="addAddr" placeholder="추가 주소를 입력해 주세요" v-model="addAddr" class="form-control" required>
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%; text-align:center">
                            <tr>
                                <th style="width:15%;">
                                    층수(층)
                                </th>
                                <th style="width:15%;">
                                    면적(m2)
                                </th>
                                <th style="width:15%;">
                                    방향
                                </th>
                                <th style="width:15%;">
                                    방 개수
                                </th>
                                <th style="width:20%;">
                                    욕실 개수
                                </th>
                                <th style="width:20%;">
                                    준공 년월
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="text" id="layer" name="layer" v-model="layer" class="form-control" placeholder="층수 입력">
                                </th>
                                <th>
                                    <input type="text" id="area" name="area" v-model="area" class="form-control" placeholder="면적 입력">
                                </th>
                                <th>
                                    <input type="text" id="direction" name="direction" v-model="direction" class="form-control" placeholder="방향 입력">
                                </th>
                                <th>
                                    <input type="text" id="room" name="room" v-model="room" class="form-control" placeholder="방의 개수 입력">
                                </th>
                                <th>
                                    <input type="text" id="bathroom" name="bathroom" v-model="bathroom" class="form-control" placeholder="욕실 개수 입력">
                                </th>
                                <th>
                                    <input type="text" id="yearMonth" name="yearMonth" v-model="yearMonth" class="form-control" placeholder="준공 년월 입력">
                                </th>
                            </tr>
                            <br>
                        </table>
                        <table style="width: 100%">
                            <tr>
                                <th style="text-align:center;">
                                    매물 특징(부대시설/교통/주변시설 등)
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <textarea class="form-control" style="width:100%;" v-model="addValue" id="addValue" name="addValue"></textarea>
                                </th>
                            </tr>
                            <br>
                            <br>
                        </table>
                        <div id="imp">*층수, 면적, 방수, 욕실개수는 숫자만 입력 해주세요</div>
                        <br>
                        <br>
                        <input type="text" id="dongCode" name="dongCode" style="display:none;">
                        <input type="text" id="lat" name="lat" style="display:none;">
                        <input type="text" id="lng" name="lng" style="display:none;">
                        
                        <br><h5>거래조건</h5>
                        <table style="line-height:60%; width: 100%; text-align:center">
                            <tr v-if="type==='매매' || type===''" v-cloak>
                                <th style="width:70%;">
                                    매매가(만원 단위)
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <tr v-if="type==='전세'" v-cloak>
                                <th style="width:70%;">
                                    전세가
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <tr v-if="type==='월세'" v-cloak>
                                <th style="width:35%;">
                                    보증금
                                </th>
                                <th style="width:35%;">
                                    월세
                                </th>
                                <th style="width:30%;">
                                    융자
                                </th>
                            </tr>
                            <br>
                            <tr v-if="type==='매매' || type===''" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="price" class="form-control" placeholder="매매가 입력" required>
                                </th>
                                <th>
                                    <input type="text" id="financing" name="financing" v-model="financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                            <tr v-if="type==='전세'" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="price" class="form-control" placeholder="전세가 입력" required>
                                </th>
                                <th>
                                    <input type="text" id="financing" name="financing" v-model="financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                            <tr v-if="type==='월세'" v-cloak>
                                <th>
                                    <input type="text" id="price" name="price" v-model="price" class="form-control" placeholder="보증금 입력" required>
                                </th>
                                <th>
                                    <input type="text" id="monthPrice" name="monthPrice" v-model="monthPrice" class="form-control" placeholder="월세 입력" required>
                                </th>
                                <th>
                                    <input type="text" id="financing" name="financing" v-model="financing" class="form-control" placeholder="융자 입력" required>
                                </th>
                            </tr>
                        </table>
                        <br>

                        <table style="line-height:70%; width: 100%; text-align:center;">
                            <tr>
                                <th style="width:70%;">
                                    입주 가능일
                                </th>
                                <th style="width:30%;">
                                    가격조정 가능 여부
                                </th>
                            </tr>
                            <br>
                            <tr>
                                <th>
                                    <input type="date" id="date" name="date" v-model="date" class="form-control" placeholder="입주 가능일 입력" required>
                                </th>
                                <th>
                                    <input style="display:inline-block; width:20px; left:100px" id="deal" type="checkbox" class="form-control" name="deal" v-model="deal" true-value="1" false-value="0">
                                </th>
                            </tr>
                            <br>
                        </table>
                        <br>
                        <div style="text-align: center;">
                            <button id="allowEdit" class="btn btn-primary font-weight-bold mb-2 col-5 mr-1" type="button" v-on:click="register">등록 완료</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script src="https://t1.daumcdn.net/mapjsapi/bundle/postcode/prod/postcode.v2.js"></script>
<script>
import http from "../../http-common";
import { mapGetters } from "vuex";

export default {
    name: 'House_register',
    data() {
        return {
            id: '',
            tel: '',
            type: '',
            houseType: '',
            postCode: '',
            addr: '',
            dongCode: '',
            addAddr: '',
            layer: '',
            area: '',
            direction: '',
            room: '',
            bathroom: '',
            yearMonth: '',
            addValue: '',
            price: '',
            monthPrice: '',
            financing: '',
            date: null,
            deal: 0,
            lat: '',
            lng: '',
            no: '',
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        post_search: function() {
            
            new daum.Postcode({
                oncomplete(data) {
                    var ad = '';

                    if(data.userSelectedType==='R'){
                        ad = data.roadAddress;
                    } else {
                        ad = data.jibunAddress;
                    }

                    document.getElementById('addr').value = ad;
                    document.getElementById('postCode').value = data.zonecode;
                    document.getElementById('dongCode').value = data.bcode;

                    var geocoder = new kakao.maps.services.Geocoder();

                    geocoder.addressSearch(ad, function(result, status) {
                        if (status === kakao.maps.services.Status.OK) {
                            document.getElementById('lat').value=result[0].y;
                            document.getElementById('lng').value=result[0].x;
                        } 
                    });
                }
            }).open()
        },
        register: function() {
            this.postCode=document.getElementById('postCode').value;
            this.dongCode=document.getElementById('dongCode').value;
            this.addr=document.getElementById('addr').value;
            this.lat=document.getElementById('lat').value;
            this.lng=document.getElementById('lng').value;

            if (this.tel == ""){
                alert("전화번호를 입력하세요.");
                return;
            }
            if (this.type == "") {
                alert("거래 방법을 선택하세요.");
                return;
            }
            if (this.houseType == "") {
                alert("거래할 집 종류를 선택하세요.");
                return;
            }
            if (this.postCode == "") {
                alert("주소를 검색하세요.");
                return;
            }
            if (this.addAddr == "") {
                alert("상세 주소를 입력하세요.");
                return;
            }
            if (this.price == "") {
                alert("거래 가격을 입력하세요.");
                return;
            }
            if (this.monthPrice == "" && this.type == "월세") {
                alert("월세를 입력하세요.");
                return;
            }
            if (this.date == null) {
                alert("입주가능일을 선택하세요.");
                return;
            }
            
            http
                .post("/house/", {
                    id: this.id,
                    tel: this.tel,
                    type: this.type,
                    houseType: this.houseType,
                    postCode: this.postCode,
                    dongCode: this.dongCode,
                    addr: this.addr,
                    addAddr: this.addAddr,
                    layer: this.layer,
                    area: this.area,
                    direction: this.direction,
                    room: this.room,
                    bathroom: this.bathroom,
                    yearMonth: this.yearMonth,
                    addValue: this.addValue,
                    price: this.price,
                    monthPrice: this.monthPrice,
                    financing: this.financing,
                    date: this.date,
                    deal: this.deal,
                    lat: this.lat,
                    lng: this.lng
                })
            .then((success) => {
                console.log(success);
                this.$router.push("/myhouselist")
            })
        }
    },
    mounted() {
        if(!this.getisLogin){
            alert("매물 등록 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            const script = document.createElement('script');
            script.src = 'http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=dea07b77c50fd259ffad8bbe6d94165b&libraries=services,clusterer,drawing';
            document.head.appendChild(script);
            this.id=this.getUserId;
        }
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
#imp {
    font-size: 10px;
    text-align: right;
    color: red;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
