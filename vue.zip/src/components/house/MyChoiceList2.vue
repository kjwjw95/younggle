<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">방문예약</h2>
                        <div>
                            <div style="width: 100%;"><h5>받은 신청</h5></div>
                            <table style="width: 100%;" class="table table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th style="text-align:center; width: 16%;">방문날짜</th>
                                        <th style="text-align:center; width: 25%;">신청날짜</th>
                                        <th style="text-align:center; width: 35%;">주소</th>
                                        <th style="text-align:center; width: 24%;">승낙/거절</th>
                                    </tr>
                                </thead>
                                <tbody v-if="(reservations != null)" id = "searchResult">
                                    <tr v-for="(reservation,index) in reservations" class="reservations" data-status="active" v-bind:key="index">
                                        <td id="type" style="text-align:center;" v-on:click="detail(reservation.no)">{{reservation.date}}</td>
                                        <td id="houseType" style="text-align:center;" v-on:click="detail(reservation.no)">{{reservation.reservDate}}</td>
                                        <td id="houseType" style="text-align:center;" v-on:click="detail(reservation.no)">{{reservation.addr}}</td>
                                        <td id="type" style="text-align:center;">
                                            <button v-if="(reservation.value==0)" id="allowEdit" class=" col-3.5" type="button" v-on:click="reservOk(reservation.num)">승낙</button>
                                            <button v-if="(reservation.value==0)" id="allowEdit" class=" col-3.5" type="button" v-on:click="reservDelete(reservation.num)">거절</button>
                                            <a v-else>확정</a>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";
import { mapGetters } from "vuex";

export default {
    name: 'MyReservationList',
    data() {
        return {
            loading: true,
            errored: false,
            reservations: []
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        detail: function(no) {
            this.$router.push("/house/" + no);
        },
        reservDelete: function(num) {
            http
            .delete("/house/reservation/" + num)
            .then((success) => {
                console.log(success);
                this.$router.push('reservlist');
            })
        },
        reservOk: function(num) {
            http
            .put("/house/reservation/" + num)
            .then((success) => {
                console.log(success);
                this.$router.push('reservlist');
            })
        }
    },
    created() {
        if(!this.getisLogin){
            alert("방문예약 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            http
              .get("/house/rereservation/" + this.getUserId)
              .then(response => (this.reservations = response.data))
              .catch(() => {
                this.errored = true;
              })
              .finally(() => (this.loading = false));
        }
    }
}
</script>

<style scoped>
#top {
    font-weight: 500;
    color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
