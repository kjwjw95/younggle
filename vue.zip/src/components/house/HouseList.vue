<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">매물 검색</h2>
                        <table style="width:100%;">
                            <tbody>
                                <tr style="text-align:center; font-size: 14px">
                                    <td style="width:12.5%;">지역</td>
                                    <td style="width:12.5%;">
                                        <select v-model="sido" id="sido" name="sido" class="form-control" style="float:left; height: 30px; font-size: 10px" v-on:change="sidoChange">
                                            <option value="00">시/도</option>
                                            <option v-for="(sido, index) in sidoList" v-bind:value="sido.dongCode" v-bind:key="index">{{sido.sido}}</option>
                                        </select>
                                    </td>
                                    <td style="width:12.5%;">
                                        <select v-model="gugun" id="gugun" name="gugun" class="form-control" style="float:left; height: 30px; font-size: 10px" v-on:change="gugunChange">
                                            <option value="000">시/군/구</option>
                                            <option v-for="(gugun, index) in gugunList" v-bind:value="gugun.dongCode" v-bind:key="index">{{gugun.gugun}}</option>
                                        </select>
                                    </td>
                                    <td style="width:12.5%;">
                                        <select v-model="dong" id="dong" name="type" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="000">읍/면/동</option>
                                            <option v-for="(dong, index) in dongList" v-bind:value="dong.dongCode" v-bind:key="index">{{dong.dong}}</option>
                                        </select>
                                    </td>
                                    <td style="width:12.5%;">매매 유형</td>
                                    <td style="width:12.5%;">
                                        <select v-model="type" name="type" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="매매">매매</option>
                                            <option value="전세">전세</option>
                                            <option value="월세">월세</option>
                                        </select>
                                    </td>
                                    <td style="width:12.5%;">매물 종류</td>
                                    <td style="width:12.5%;">
                                        <select v-model="houseType" name="houseType" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="아파트">아파트</option>
                                            <option value="오피스텔">오피스텔</option>
                                            <option value="빌라">빌라</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr style="height:20px">
                                </tr>
                                <tr style="text-align:center; font-size: 14px">
                                    <td v-if="type==='0'">금액(원)</td>
                                    <td v-else-if="type==='매매'">매매가</td>
                                    <td v-else-if="type==='전세'">전세가</td>
                                    <td v-else-if="type==='월세'">보증금/월세</td>
                                    <td v-if="type==='0'" colspan='3'>
                                        <select v-model="price" name="price" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="500">5백만 이하</option>
                                            <option value="1000">5백만~1천만 이하</option>
                                            <option value="2000">1천만~2천만 이하</option>
                                            <option value="5000">2천만~5천만 이하</option>
                                            <option value="10000">5천만~1억 이하</option>
                                            <option value="20000">1억~2억 이하</option>
                                            <option value="50000">2억~5억 이하</option>
                                            <option value="100000">5억~10억 이하</option>
                                            <option value="1">10억 초과</option>
                                        </select>
                                    </td>
                                    <td v-else-if="type==='매매'" colspan='3'>
                                        <select v-model="price" name="price" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="500">5백만 이하</option>
                                            <option value="1000">5백만~1천만 이하</option>
                                            <option value="2000">1천만~2천만 이하</option>
                                            <option value="5000">2천만~5천만 이하</option>
                                            <option value="10000">5천만~1억 이하</option>
                                            <option value="20000">1억~2억 이하</option>
                                            <option value="50000">2억~5억 이하</option>
                                            <option value="100000">5억~10억 이하</option>
                                            <option value="1">10억 초과</option>
                                        </select>
                                    </td>
                                    <td v-else-if="type==='전세'" colspan='3'>
                                        <select v-model="price" name="price" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="500">5백만 이하</option>
                                            <option value="1000">5백만~1천만 이하</option>
                                            <option value="2000">1천만~2천만 이하</option>
                                            <option value="5000">2천만~5천만 이하</option>
                                            <option value="10000">5천만~1억 이하</option>
                                            <option value="20000">1억~2억 이하</option>
                                            <option value="50000">2억~5억 이하</option>
                                            <option value="100000">5억~10억 이하</option>
                                            <option value="1">10억 초과</option>
                                        </select>
                                    </td>
                                    <td v-else-if="type==='월세'" colspan='3'>
                                        <select v-model="price" name="price" class="form-control" style="float:left; width:50%; height: 30px; font-size: 10px; display:inline-block;">
                                            <option value="0">미선택</option>
                                            <option value="500">5백만 이하</option>
                                            <option value="1000">5백만~1천만 이하</option>
                                            <option value="2000">1천만~2천만 이하</option>
                                            <option value="5000">2천만~5천만 이하</option>
                                            <option value="10000">5천만~1억 이하</option>
                                            <option value="20000">1억~2억 이하</option>
                                            <option value="50000">2억~5억 이하</option>
                                            <option value="100000">5억~10억 이하</option>
                                            <option value="1">10억 초과</option>
                                        </select>
                                        <select v-model="monthPrice" name="monthPrice" class="form-control" style="float:left; width:50%; height: 30px; font-size: 10px; display:inline-block;">
                                            <option value="0">미선택</option>
                                            <option value="20">2십만 이하</option>
                                            <option value="50">2십만~5십만 이하</option>
                                            <option value="100">5십만~1백만 이하</option>
                                            <option value="200">1백만~2백만 이하</option>
                                            <option value="500">2백만~5백만 이하</option>
                                            <option value="1000">5백만~1천만 이하</option>
                                            <option value="1">1천만 초과</option>
                                        </select>
                                    </td>
                                    <td>면적(m2)</td>
                                    <td>
                                        <select v-model="area" name="area" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="66">66이하</option>
                                            <option value="82.5">66~82.5</option>
                                            <option value="99">82.5~99</option>
                                            <option value="115.7">99~115.7</option>
                                            <option value="148.7">115.7~148.7</option>
                                            <option value="1">148.7초과</option>
                                        </select>
                                    </td>
                                    <td>방수</td>
                                    <td>
                                        <select v-model="room" name="room" class="form-control" style="float:left; height: 30px; font-size: 10px">
                                            <option value="0">미선택</option>
                                            <option value="1">1개</option>
                                            <option value="2">2개</option>
                                            <option value="3">3개</option>
                                            <option value="4">4개</option>
                                            <option value="5">5개 이상</option>
                                        </select>
                                    </td>
                                </tr>
                                <tr style="height:20px">
                                </tr>
                                <tr>
                                    <td>
                                        <select style="width:100%;" v-model="typeChoice" id="type" name="type" class="custom-select">
                                            <option value="0">All</option>
                                            <option value="1">상세 주소</option>
                                            <option value="2">매물 특징</option>
                                        </select>
                                    </td>
                                    <td colspan='6'>
                                        <input v-if="typeChoice==='0'" v-model="keyword" id="keyword" name="keyword" type="search" class="form-control" placeholder="검색어를 입력하세요." required autofocus readonly>
                                        <input v-else id="keyword" v-model="keyword" name="keyword" type="search" class="form-control" placeholder="검색어를 입력하세요." required autofocus>
                                    </td>
                                    <td>
                                        <button style="width:100%;" id="search" class="btn btn-primary text-uppercase font-weight-bold" type="button" v-on:click="search">검색</button>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <table class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th style="width:14%; text-align:center;">매매 유형</th>
                                    <th style="width:14%; text-align:center;">매물 종류</th>
                                    <th style="width:35%; text-align:center;">지역</th>
                                    <th style="width:35%; text-align:center;">상세 주소</th>
                                </tr>
                            </thead>
                            <tbody v-if="(houses.length)" id = "searchResult">
                                <tr v-for="(house,index) in houses" class="houses" data-status="active" v-bind:key="index">
                                    <td id="type" style="text-align:center;" v-on:click="detail(house.no)">{{house.type}}</td>
                                    <td id="houseType" style="text-align:center;" v-on:click="detail(house.no)">{{house.houseType}}</td>
                                    <td id="addr" v-on:click="detail(house.no)">{{house.addr}}</td>
                                    <td id="addAddr" v-on:click="detail(house.no)">{{house.addAddr}}</td>
                                </tr>
                            </tbody>
                            <tbody v-else-if="(houses.length==0)" id = "searchResult">
                            <h4 >판매중인 매물이 없습니다.</h4>
                            </tbody>
                            <!-- <page-link/> -->
                        </table>
                    </div>
                </div>
                <page-link ref="pagelink"/>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";
import PageLink from "./PageLink.vue";
// import PageLink from "../PageLink.vue";
export default {
    name: 'MyHouseList',
    data() {
        return {
            loading: true,
            errored: false,
            houses: [],
            typeChoice: '0',
            type: '0',
            houseType: '0',
            keyword: '0',
            sidoList: [],
            gugunList: [],
            dongList: [],
            sido: '00',
            gugun: '000',
            dong: '000',
            price: '0',
            monthPrice: '0',
            area: '0',
            room: '0',
            choices: [],
            pageLimit: 10,
            pageOffset: 0,
            listRowCount: 1
        };
    },
    methods: {
        detail: function(no) {
            this.$router.push("/house/" + no);
        },
        sidoChange: function() {
            http
                .get("/region/gugunList/" + this.sido)
                .then(response => (this.gugunList = response.data))
                .catch(() => {
                    this.errored = true;
                })
                .finally(() => (this.loading = false));
                this.gugun="000";
                this.dong="000";
        },
        gugunChange: function() {
            http
                .get("/region/dongList/" + this.sido + this.gugun)
                .then(response => (this.dongList = response.data))
                .catch(() => {
                    this.errored = true;
                })
                .finally(() => (this.loading = false));
                this.dong="000";
        },
        search: function() {
            var dongCode="0";
            if(this.sido!='00'){
                dongCode="";
                dongCode+=this.sido;
                if(this.gugun!='000'){
                    dongCode+=this.gugun;
                    if(this.dong!='000'){
                        dongCode+=this.dong;
                    }
                }
            }
            this.initComponent();
           http
        .get("/house/pagelink/counts",{
                params: {dongCode : dongCode,
                type: this.type, houseType: this.houseType, price: this.price, monthPrice: this.monthPrice,
                area: + this.area, room: this.room, typeChoice: this.typeChoice, keyword: this.keyword}
                })
        .then(({ data })=> {
            this.$refs.pagelink.initComponent(data);
            console.log(data+"++++++++++++++++");
            this.$refs.pagelink.movePage(1);
        })
        .catch(() => {
            alert("에러가 발생했습니다.!!!!!!!!!!!!!");
        });
        },
        initComponent(){

            var dongCode="0";
            if(this.sido!='00'){
                dongCode="";
                dongCode+=this.sido;
                if(this.gugun!='000'){
                    dongCode+=this.gugun;
                    if(this.dong!='000'){
                        dongCode+=this.dong;
                    }
                }
            }
            http
            .get("/house/pagelink",{
                params: {limit: this.pageLimit, offset: `${this.$route.query.no - this.pageLimit}`, dongCode : dongCode,
                type: this.type, houseType: this.houseType, price: this.price, monthPrice: this.monthPrice,
                area: + this.area, room: this.room, typeChoice: this.typeChoice, keyword: this.keyword}
            })
            .then(response => (this.houses = response.data))
            .catch(() => {
                this.errored = true;
                console.log("에러발생");
            })
            .finally(() => (this.loading = false));
        }
    },
    created() {
        this.initComponent();
        console.log(this.houses);
        http
            .get("/region/sidoList")
            .then(response => (this.sidoList = response.data))
            .catch(() => {
                this.errored = true;
            })
            .finally(() => (this.loading = false));
    },
  components: {
     PageLink
  },
  watch: {
    '$route.query': function(){
      this.initComponent();
    }
  },
}
</script>

<style scoped>
#top {
    font-weight: 500;
    color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
