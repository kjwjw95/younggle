<template>
  <div id="tab">
    <header class="masthead">
      <div class="container h-100">
        <div class="row h-100 align-items-center mt=5">
          <div class="col-12 text-center">
            <h1 class="font-weight-light">실거래 정보 검색!</h1>

            <form method="get" action="" id="searchForm">
              <div class="row">
                <div class="input-group col-2 ml-5">
                  <select
                    id="type"
                    name="type"
                    class="custom-select"
                    v-model="ctype"
                  >
                    <option selected value="all">All</option>
                    <option value="dong">동</option>
                    <option value="name">아파트 이름</option>
                  </select>
                </div>
                <div class="form-label-group col-7 pr-0">
                  <input
                    id="keyword"
                    name="keyword"
                    type="search"
                    class="form-control"
                    placeholder="search"
                    v-model="ckeyword"
                    required
                    autofocus
                  />
                </div>
                <div class="col-2 pl-0">
                  <button
                    id="search"
                    class="btn btn-primary btn-login text-uppercase font-weight-bold"
                    type="button"
                    v-on:click="search_housedeal"
                  >
                    검색
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </header>

    <div class="container-xl">
      <div class="text-center">
        <input type="checkbox" name="status" value="house1" checked="checked" />
        주택 전월세
        <input type="checkbox" name="status" value="house2" checked="checked" />
        주택 매매
        <input
          type="checkbox"
          name="status"
          value="apartment1"
          checked="checked"
        />
        아파트 전월세
        <input
          type="checkbox"
          name="status"
          value="apartment2"
          checked="checked"
        />
        아파트 매매

        <form method="get" action="${root}/map" id="sortForm">
          <input
            type="hidden"
            name="keyword"
            id="pre-keyword"
            value="${keyword}"
          />
          <input type="hidden" name="type" id="pre-type" value="${type}" />
          <input
            type="hidden"
            name="sortType"
            id="sortType"
            value="${sortType}"
          />
          <button
            id="sortPrice"
            class="btn btn-primary btn-login"
            type="button"
          >
            거래금액 정렬
          </button>
        </form>
      </div>
      <div id="tab" class="table-responsive" v-if="this.info.length > 0">
        <div class="table-wrapper">
          <table class="table table-striped table-hover">
            <thead>
              <tr>
                <th>NO</th>
                <th>동</th>
                <th>아파트 이름</th>
                <th>거래금액</th>
                <th>건축년도</th>
                <th></th>
              </tr>
            </thead>
            <tbody id="searchResult">
              <tr v-for="housedeal in paginatedData" class="house" :key="housedeal.no">
                <td id="no" v-html="housedeal.no"></td>
                <td id="dong" v-html="housedeal.dong"></td>
                <td id="aptName" v-html="housedeal.aptName"></td>
                <td id="dealAmount" v-html="housedeal.dealAmount"></td>
                <td id="buildYear" v-html="housedeal.buildYear"></td>
                <!--
                <td id="house-${no}">
                  <a
                    href="${root}/main.do?action=HOUSE-DETAIL&no=${houseDeal.no}&id=${member.email}"
                    class="btn btn-sm manage"
                    >보기</a
                  >
                </td> -->
              </tr>
            </tbody>
          </table>
        </div>
        <div class="btn-cover">
          <button :disabled="pageNum === 0" @click="prevPage" class="page-btn">
            이전
          </button>
          <span class="page-count"
            >{{ pageNum + 1 }} / {{ pageCount }} 페이지</span
          >
          <button
            :disabled="pageNum >= pageCount - 1"
            @click="nextPage"
            class="page-btn"
          >
            다음
          </button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import http from "../http-common";
export default {
  name: "housedeal",
  props: ["no"],
  data() {
    return {
      upHere: false,
      info: [],
      cid: "",
      loading: true,
      errored: false,
      ctype: "all",
      ckeyword: "",
      pageNum: 0,
      pageSize: 5,
    };
  },
  methods: {
    deal_list: function () {
      this.$router.push("/searchall");
    },
    search_housedeal: function () {
      if (this.ctype == "all") {
        console.log(this.info.length);
        http
          .get("/house/searchalls")
          .then((response) => (this.info = response.data))
          .catch(() => {
            this.errored = true;
          })
          .finally(() => (this.loading = false));
      }
    },
    nextPage() {
      this.pageNum += 1;
    },
    prevPage() {
      this.pageNum -= 1;
    },
  },
  computed: {
    pageCount: function ()  {
      let listLeng = this.info.length,
        listSize = this.pageSize,
        page = Math.floor((listLeng - 1) / listSize) + 1;
      return page;
    },
    paginatedData: function ()  {
      const start = this.pageNum * this.pageSize,
        end = start + this.pageSize;
      return this.info.slice(start, end);
    },
  }
};
</script>
