<template>
  <div id="tab" class="container-fluid">
    <div class="d-flex align-items-center py-5">
      <div class="container">
        <div class="row">
          <div class="col-lg-10 mx-auto">
            <h2 class="login-heading mb-4"></h2>
            <div style="width: 100%">
              <table style="width: 100%">
                <tbody>
                  <tr style="text-align: center; font-size: 14px">
                    <td style="width: 15%">지역</td>
                    <td style="width: 15%">
                      <select v-model="sido" id="sido" name="sido" class="form-control" style="float: left; height: 30px; font-size: 10px" v-on:change="sidoChange">
                        <option value="00">시/도</option>
                        <option v-for="(sido, index) in sidoList" v-bind:value="sido.dongCode" v-bind:key="index">
                          {{ sido.sido }}
                        </option>
                      </select>
                    </td>
                    <td style="width: 15%">
                      <select v-model="gugun" id="gugun" name="gugun" class="form-control" style="float: left; height: 30px; font-size: 10px" v-on:change="gugunChange">
                        <option value="000">시/군/구</option>
                        <option v-for="(gugun, index) in gugunList" v-bind:value="gugun.dongCode" v-bind:key="index">
                          {{ gugun.gugun }}
                        </option>
                      </select>
                    </td>
                    <td style="width: 15%">
                      <select v-model="dong" id="dong" name="type" class="form-control" style="float: left; height: 30px; font-size: 10px" v-on:change="dongChange">
                        <option value="000">읍/면/동</option>
                        <option v-for="(dong, index) in dongList" v-bind:value="dong.dongCode" v-bind:key="index">
                          {{ dong.dong }}
                        </option>
                      </select>
                    </td>
                    <td style="width: auto"></td>
                  </tr>
                </tbody>
              </table>
              <br />
              <div style="width: 100%; height: 400px" id="map"></div>
            </div>
            <div style="width: 100%; height:300px;" v-if="houseList.length > 0">
              <table style="width: 100%" class="table table-striped table-hover">
                <thead>
                  <tr>
                    <th style="width: 33%; text-align: center">주소</th>
                    <th style="width: 22%; text-align: center">상세 주소</th>
                    <th style="width: 15%; text-align: center">매매 유형</th>
                    <th style="width: 15%; text-align: center">매물 종류</th>
                    <th style="width: 15%; text-align: center">가격(만원)</th>
                  </tr>
                </thead>
                <tbody id="searchResult">
                  <tr v-for="(house, index) in houseList" class="houses" data-status="active" v-bind:key="index">
                    <td id="type" v-on:click="detail(house.no)">
                      {{ house.addr }}
                    </td>
                    <td id="type" v-on:click="detail(house.no)">
                      {{ house.addAddr }}
                    </td>
                    <td id="type" style="text-align: center" v-on:click="detail(house.no)">
                      {{ house.type }}
                    </td>
                    <td id="type" style="text-align: center" v-on:click="detail(house.no)">
                      {{ house.houseType }}
                    </td>
                    <td id="type" style="text-align: center" v-on:click="detail(house.no)">
                      {{ house.price }}
                    </td>
                  </tr>
                </tbody>
              </table>
              <div class="btn-cover" style="text-align: center; vertical-align: bottom;">
                <button :disabled="pageNum === 0" @click="prevPage" class="page-btn">
                  이전
                </button>
                <span class="page-count">{{ pageNum + 1 }} / {{ pageCount }} 페이지</span>
                <button :disabled="pageNum >= pageCount - 1" @click="nextPage" class="page-btn">
                  다음
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script type="text/javascript" src="//dapi.kakao.com/v2/maps/sdk.js?appkey=dea07b77c50fd259ffad8bbe6d94165b&libraries=services,clusterer,drawing"></script>
<script>
import http from "../http-common";

export default {
  name: "MainPage",
  data() {
    return {
      loading: true,
      errored: false,
      //테스트용 나중에 수정
      id: "test",
      houses: [],
      sido: "00",
      gugun: "000",
      dong: "000",
      sidoList: [],
      gugunList: [],
      dongList: [],
      houseList: [],
      map: null,
      markers: [],
      sidoname: "",
      gugunname: "",
      dongname: "",
      pageNum: 0,
      pageSize: 8,
      size: '',
      ch: '2',
      specList: []
    };
  },
  methods: {
    detail: function (no) {
      this.$router.push("/house/" + no);
    },
    initMap() {
      var mapContainer = document.getElementById("map"), // 지도를 표시할 div
        mapOption = {
          center: new kakao.maps.LatLng(36.453012, 127.951022), // 지도의 중심좌표
          level: 14, // 지도의 확대 레벨
        };

      // 지도를 생성합니다
      if (this.map == null)
        this.map = new kakao.maps.Map(mapContainer, mapOption);
      console.log(this.map);
      this.$store.dispatch("callMap", { newMap: map });
    },
    mapchange(no) {
        var loc = this.sidoname + " " + this.gugunname + " " + this.dongname;
        var ps = new kakao.maps.services.Places();
        this.size=no;
        ps.keywordSearch(loc , this.placesSearchCB);
        console.log(loc);
    },
    placesSearchCB(data, status, pagination) {
      if (status === kakao.maps.services.Status.OK) {
        // 검색된 장소 위치를 기준으로 지도 범위를 재설정하기위해
        // LatLngBounds 객체에 좌표를 추가합니다
        var bounds = new kakao.maps.LatLngBounds();

        var moveLatLon = new kakao.maps.LatLng(data[0].y,data[0].x);
        this.map.setCenter(moveLatLon);
        if(this.size==1)
            this.map.setLevel(11);
        else if(this.size==2)
            this.map.setLevel(9);
        else if(this.size==3)
            this.map.setLevel(7);
      }
    },
    sidoChange: function () {
        this.ch = '0'
        this.initMarker();
        this.markers=[];
        this.specList=[];
        http
            .get("/region/gugunList/" + this.sido)
            .then((response) => {
            this.gugunList = response.data;
            })
            .catch(() => {
            this.errored = true;
            })
            .finally(() => (this.loading = false));
        this.gugun = "000";
        this.dong = "000";
        this.gugunname = "";
        this.dongname = "";
        if(this.sido == '00'){
            var moveLatLon = new kakao.maps.LatLng(36.453012, 127.951022);
            this.map.setCenter(moveLatLon);
            this.map.setLevel(14);
            this.sidoname = '';
        } else{
            this.sidoname = document.getElementById("sido").options[
                document.getElementById("sido").selectedIndex
            ].text;
            this.mapchange(1);
        }
        var loc = this.sido;
        http
        .get("/house/list/" + loc)
        .then((response) => {
          this.houseList = response.data;
          this.makeMarker();
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    gugunChange: function () {
        this.initMarker();
        this.markers=[];
        http
            .get("/region/dongList/" + this.sido + this.gugun)
            .then((response) => (this.dongList = response.data))
            .catch(() => {
            this.errored = true;
            })
            .finally(() => (this.loading = false));
        if(this.gugun== "000"){
            this.dong = "000";
            this.dongname = "";
            this.gugunname = "";
            this.mapchange(1);
            var loc = this.sido;
        } else{
            this.dong = "000";
            this.dongname = "";
            this.gugunname = document.getElementById("gugun").options[
                document.getElementById("gugun").selectedIndex
            ].text;
            this.mapchange(2);
            var loc = this.sido + this.gugun;
        }
        http
        .get("/house/list/" + loc)
        .then((response) => {
          this.houseList = response.data;
          this.makeMarker();
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    dongChange: function () {
        this.initMarker();
        this.markers=[];
        console.log("doncode:" + loc);
        if(this.dong=="000"){
            this.dongname = "";
            this.mapchange(2);
            var loc = this.sido + this.gugun;
        } else{
            this.dongname = document.getElementById("dong").options[
                document.getElementById("dong").selectedIndex
            ].text;
            this.mapchange(3);
            var loc = this.sido + this.gugun + this.dong;
        }
        http
        .get("/house/list/" + loc)
        .then((response) => {
          this.houseList = response.data;
          this.makeMarker();
        })
        .catch(() => {
          this.errored = true;
        })
        .finally(() => (this.loading = false));
    },
    makeMarker() {
        for (var i = 0; i < this.houseList.length; i++) {
            var title = this.houseList[i].addr;
            console.log(">>>>>>>title>>>>>>>>" + title);
            var positions = new kakao.maps.LatLng(
            this.houseList[i].lat,
            this.houseList[i].lng
            );
            var marker = new kakao.maps.Marker({
                position: positions, // 마커를 표시할 위치
                //title : houseList[i].addr+houseList[i].addAddr, // 마커의 타이틀, 마커에 마우스를 올리면 타이틀이 표시됩니다
            });
            this.markers.push(marker);
        }
        for(var i =0; i<this.markers.length;i++){
            this.markers[i].setMap(this.map);
            var iwContent = '<div style="padding:5px;">' + title + "</div>";
            var infowindow = new kakao.maps.InfoWindow({
            content: iwContent,
            });
            kakao.maps.event.addListener(
                this.markers[i],
                "mouseover",
                this.makeOverListener(this.map, marker, infowindow)
            );
            kakao.maps.event.addListener(
                this.markers[i],
                "mouseout",
                this.makeOutListener(infowindow)
            );
            kakao.maps.event.addListener(
                this.markers[i],
                "click",
                this.makeClickListener(this.houseList[i].no)
            );
        }
    },
    initMarker() {
        for(var i =0; i < this.markers.length;i++){
            this.markers[i].setMap(null);
        }
    },
    nextPage() {
      this.pageNum += 1;
    },
    prevPage() {
      this.pageNum -= 1;
    },
    makeOverListener(map, marker, infowindow) {
      return function () {
        infowindow.open(map, marker);
      };
    },
    makeOutListener(infowindow) {
      return function () {
        infowindow.close();
      };
    },
    makeClickListener(no) {
      return  ()=> {
        //   console.log(no);
        this.$router.push("/house/" + no);
      };
    },
  },
  computed: {
    pageCount: function () {
      let listLeng = this.houseList.length,
        listSize = this.pageSize,
        page = Math.floor((listLeng - 1) / listSize) + 1;
      return page;
    },
    paginatedData: function () {
      const start = this.pageNum * this.pageSize,
        end = start + this.pageSize;
      return this.houseList.slice(start, end);
    },
  },
  created() {
    const script = document.createElement("script");
    script.onload = () => kakao.maps.load(this.initMap);
    script.src =
      "http://dapi.kakao.com/v2/maps/sdk.js?autoload=false&appkey=dea07b77c50fd259ffad8bbe6d94165b&libraries=services,clusterer,drawing";
    document.head.appendChild(script);
    http
      .get("/region/sidoList")
      .then((response) => (this.sidoList = response.data))
      .catch(() => {
        this.errored = true;
      })
      .finally(() => (this.loading = false));
  },
};
</script>

<style scoped>
#top {
  font-weight: 500;
  color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>