<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">1:1 문의하기</h2>

                        <table style="width: 100%;" class="table table-striped table-hover">
                            <tbody id = "searchResult">
                                <tr>
                                    <th style="width:20%; text-align:center;">문의 유형</th>
                                    <th style="width:80%; text-align:center;">
                                        <select v-model="selected" name="questionType" class="form-control" v-on:change="change(selected)" style="float:left;">
                                            <option value="" selected disabled hidden>--문의 유형 선택--</option>
                                            <option value="계정">계정</option>
                                            <option value="신고">신고</option>
                                            <option value="건의사항">건의사항</option>
                                            <option value="일반">일반</option>
                                        </select>
                                    </th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">제목</th>
                                    <th style="width:80%; text-align:center;"><input type="text" class="form-control" style="width:100%" v-model="title"></th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">내용</th>
                                    <th style="width:80%;"><textarea style="width:100%; height:300px" class="form-control" v-model="question_describe"></textarea></th>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <div style="text-align: center;">
                            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="addQuestion">작성 완료</button>
                            <router-link class="nav-link" to="/question" style="display:inline-block;">
                              <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button">취소</button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";
import { mapGetters } from "vuex";

export default {
    name: 'QuestionWrite',
    data() {
        return {
            loading: true,
            errored: false,
            title: null,
            questionType: "",
            question_describe: null,
            top: null,
            selected: ""
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
      addQuestion() {
        if (this.questionType==""){
          alert("문의 유형을 선택하세요.");
          return;
        }
        if (this.title == "") {
          alert("제목을 입력하세요.");
          return;
        }
        if (this.question_describe == "") {
          alert("내용을 입력하세요.");
          return;
        }

        http
          .post("/question/", {
            id: this.getUserId,
            questionType: this.questionType,
            title: this.title,
            question_describe: this.question_describe
          })
          .then((success) => {
            console.log(success);
            this.$router.push("/question")
            })
      },
        change: function(input){
            this.questionType = input;
        }
    },
    mounted() {
        if(!this.getisLogin){
            alert("질문 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        }
    }
}
</script>

<style scoped>
pre {
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  white-space: pre-wrap;
  word-wrap: break-word;
}
#top {
  font-weight: 500;
  color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
