<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">문의 내역</h2>

                        <table style="width: 100%" class="table table-striped table-hover">
                            <thead>
                                <tr>
                                    <th style="width:15%; text-align:center;">문의 유형</th>
                                    <th style="width:55%; text-align:center;">제목</th>
                                    <th style="width:15%; text-align:center;">작성일시</th>
                                    <th style="width:15%; text-align:center;">답변</th>
                                </tr>
                            </thead>
                            <tbody v-if="(questions != null)" id = "searchResult">
                                <tr v-for="(question,index) in questions" class="questions" data-status="active" v-bind:key="index">
                                    <td id="no" style="text-align:center;">{{question.questionType}}</td>
                                    <td id="title" v-on:click="detail(question.no)">{{question.title}}</td>
                                    <td id="date" style="text-align:center;">{{question.writetime}}</td>
                                    <td id="reply" style="text-align:center;"><div v-if="(question.reply != null)">답변완료</div></td>
                                </tr>
                            </tbody>
                            <h4 v-else-if="(questions == null)">문의 내역이 없습니다.</h4>
                        </table>
                        <br>
                        <!-- 어드민 설정 -->
                        <div v-if="(getUserId != '1541781079')" class="nav-link" style="text-align: center;">
                            <router-link to="/question/write">
                                <button id="allowEdit" class="btn btn-primary font-weight-bold"
                                    type="button">1:1 문의하기</button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";
import { mapGetters } from "vuex";

export default {
    name: 'Question',
    data() {
        return {
            loading: true,
            errored: false,
            questions: [],
            pageLimit : 10,
            pageOffet : 0
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        detail: function(no) {
            this.$router.push("/question/" + no);
        },
        initComponent(){
      http
        .get('/question/pagelink',{
            params: { limit: this.pageLimit, offset: `${this.$route.query.no - this.pageLimit}`}
          })
        .then(({ data }) => {
          this.questions = data
        })
        .catch(() => {
          alert('에러가 발생했습니다.');
        });
    }
    },
    created() {
        if(!this.getisLogin){
            alert("질문 페이지는 로그인후 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            this.initComponent();
            // http
            // .get("/question/list/" + this.getUserId)
            // .then(response => (this.questions = response.data))
            // .catch(() => {
            //     this.errored = true;
            // })
            // .finally(() => (this.loading = false));
        }
    },
  watch: {
    '$route.query': function(){
      this.initComponent();
    }
  }
}
</script>

<style scoped>
#top {
    font-weight: 500;
    color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
