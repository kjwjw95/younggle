<template>
  <div>
    <nav class="navbar navbar-expand-lg navbar-light bg-light" style="text-align: center">
      <div id="head" class="container-fluid center">
        <div class="logo" style="float: left;" v-on:click="main">
          <a><img src="../../public/logo.jpg" /></a>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent" style="float:left; ">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <router-link class="nav-link" to="/house">매물 검색</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/houseregister">매물 등록</router-link>
            </li>
            <li class="nav-item">
              <router-link class="nav-link" to="/myhouselist">내 매물 목록</router-link>
            </li>
            <!-- 어드민 설정 -->
            <li v-if="getUserId != '어드민'" class="nav-item dropdown">
              <router-link class="nav-link dropdown-toggle" to="/reservlist">방문예약</router-link>
              <ul class="navbar-nav mr-auto dropdown-sub" style="text-align: left">
                <li class="nav-item">
                  <router-link class="nav-link" to="/mychoicelist2">받은 신청</router-link>
                </li>
                <li class="nav-item">
                  <router-link class="nav-link" to="/mychoicelist">신청</router-link>
                </li>
              </ul>
            </li>
            <li class="nav-item dropdown">
              <router-link class="nav-link dropdown-toggle" to="/notice">고객센터</router-link>
              <ul class="navbar-nav mr-auto dropdown-sub" style="text-align: left">
                <li class="nav-item">
                  <router-link class="nav-link" to="/notice">공지사항</router-link>
                </li>
                <li class="nav-item">
                  <router-link class="nav-link" to="/question">1:1 문의</router-link>
                </li>
              </ul>
            </li>
            <div v-if="getisLogin" class="nav-item collapse navbar-collapse last">
              <li class="nav-item dropdown">
                <b-avatar variant="primary" v-bind:src="getImage" @click="logout"></b-avatar>
                <a class="nav-link" style="display:inline-block">{{ getUserName }}님의 마이 페이지</a>
                <ul class="navbar-nav mr-auto dropdown-sub" style="text-align: right">
                  <li class="nav-item">
                    <router-link class="nav-link" to="/question">내 문의내역</router-link>
                  </li>
                  <li class="nav-item">
                    <router-link class="nav-link" to="/myhouselist">내 매물 목록</router-link>
                  </li>
                  <li class="nav-item">
                    <router-link class="nav-link" to="/reservlist">방문예약</router-link>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" v-on:click="logout">로그아웃</a>
                  </li>
                </ul>
              </li>
            </div>
            <li v-else class="nav-item collapse navbar-collapse last">
              <a id="custom-login-btn" @click="kakaoLogin">
                <img src="//k.kakaocdn.net/14/dn/btqCn0WEmI3/nijroPfbpCa4at5EIsjyf0/o.jpg" style="width:300px; height:40px;"/>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </div>
</template>

<script type="text/javascript" src="https://developers.kakao.com/sdk/js/kakao.min.js"></script>
<script>
import callback from "./member/callback.vue";
import { mapGetters } from "vuex";

export default {
    name: "app",
    data() {
      return {
        isLogin: false,
        image: this.$store.state.image,
        token: "",
        userid: "",
        username: "",
        image: "",
        email: "",
      };
    },
    computed: {
    ...mapGetters([
      "getAccessToken",
      "getUserId",
      "getUserName",
      "getImage",
      "getisLogin",
    ]),
  },
  mouted() {
    Kakao.init("b3c7b727d804a4c6b7dab6d378846a77");
    Kakao.isInitialized();
  },
  created() {
    this.componentDidMount();
  },
  components: {
    Callback: callback
  },
  methods: {
    main() {
      if(window.location.href=='http://localhost:8080/')
        this.$router.go(0);
      else
        this.$router.push('/');
    },
    handleClickButton() {
      this.visible = !this.visible;
    },
    componentDidMount() {
      if (Kakao.Auth.getAccessToken() && !this.$store.getters.getisLogin) {
        Kakao.API.request({
          url: "/v2/user/me",
          success: (response) => {
            console.log(response.kakao_account.profile.nickname);
            this.token=Kakao.Auth.getAccessToken();
            this.userid=response.id;
            this.username=response.kakao_account.profile.nickname;
            this.image=response.kakao_account.profile.profile_image_url;
            this.email=response.kakao_account.email;
            this.Save();
          },
          fail: function (error) {
            console.log(error);
          },
        });
      }
    },
    logout() {
      Kakao.API.request({
        url: "/v1/user/unlink",
        success: function (response) {
          console.log(response);
        },
        fail: function (error) {
          console.log(error);
        },
      });
      this.$store.commit("LOGOUT");
      Kakao.Auth.logout(function () {
        redirectUri: `http://localhost:8080/`;
      });
    },
    kakaoLogin() {
      Kakao.Auth.authorize({
        redirectUri: `http://localhost:8080/callback`,
      });
    },
    NeedEmail() {
      Kakao.Auth.authorize({
        redirectUri: "http://localhost:8080/",
        scope: "gender,birthday",
      });
    },
    Save() {
      console.log("save"+this.userid);
      this.$store.commit("LOGIN", {
        token: this.token,
        userid: this.userid,
        username: this.username,
        image: this.image,
        email: this.email
      });
    },
  },
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
a{
  cursor:pointer;
}
#head {
  display:inline-block;
  width: 80%;
}
.navbar {
  height: 70px;
}
.center {
  display: inline-block;
  position: absolute;
  width: 80%;
  left:10%;
  top:15px;
}
.last {
  display: inline-block;
  position: absolute;
  right: 0px;
  top:0px;
}
.dropdown-sub {
  display: none;
}
.dropdown:hover .dropdown-sub {
  display: block;
  margin-top: 0;
  left: 10px;
}
</style>
