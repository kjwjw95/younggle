<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">공지사항</h2>

                        <table style="width: 100%;" class="table table-striped table-hover">
                            <tbody id = "searchResult">
                                <tr>
                                    <th style="width:20%; text-align:center;">제목</th>
                                    <th style="width:73%; text-align:center;"><input type="text" class="form-control" style="width:100%" v-model="title"></th>
                                    <th style="width:7%; text-align:center;"><input type="checkbox" id="top" class="form-control" v-model="top" true-value="1" false-value="0"></th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">내용</th>
                                    <th colspan='2' style="width:80%;"><textarea style="width:100%; height:300px" class="form-control" v-model="notice_describe"></textarea></th>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <div style="text-align: center;">
                            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="addNotice">작성 완료</button>
                            <router-link class="nav-link" to="/notice" style="display:inline-block;">
                              <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button">취소</button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";

export default {
    name: 'NoticeWrite',
    data() {
        return {
            loading: true,
            errored: false,
            title: null,
            notice_describe: null,
            top: null,
        };
    },
    methods: {
      addNotice() {
        if (this.title == "") {
          alert("제목을 입력하세요.");
          return;
        }
        if (this.notice_describe == "") {
          alert("내용을 입력하세요.");
          return;
        }

        http
          .post("/notice/", {
            title: this.title,
            notice_describe: this.notice_describe,
            top: this.top,
          })
          .then((success) => {
            console.log(success);
            this.$router.push("/notice")
            })
      }
    },
    mounted() {
        if(!this.getisLogin){
            alert("공지 입력 페이지는 관리자만 사용 가능합니다.");         
            this.$router.go(-1);
        }
    }
}
</script>

<style scoped>
pre {
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  white-space: pre-wrap;
  word-wrap: break-word;
}
table {
  margin: 10px;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
