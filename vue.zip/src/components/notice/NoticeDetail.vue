<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">공지사항</h2>
                        <table v-if="(notice.title != null)" style="width: 100%;" class="table table-striped table-hover">
                            <tbody id = "searchResult">
                                <tr>
                                    <th style="width:20%; text-align:center;">제목</th>
                                    <th style="width:80%; text-align:center;">{{ notice.title }}</th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">날짜</th>
                                    <th style="width:80%; text-align:center;">{{ notice.writetime }}</th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">내용</th>
                                    <th style="width:80%;"><pre style="width: 100%; height: 100%; overflow: auto;">{{ notice.notice_describe }}</pre></th>
                                </tr>
                            </tbody>
                        </table>
                        <h4  v-else-if="(notice.title == null)">해당 공지사항은 삭제 되었습니다.</h4>
                        <br>
                        <div style="text-align: center;">
                          <!-- 어드민 설정 -->
                            <button v-if="(notice.title != null && this.getUserId =='1541781079')" id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="modifyNotice">수정</button>
                            <button v-if="(notice.title != null && this.getUserId =='1541781079')" id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="deleteNotice">삭제</button>
                            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="Notice">목록</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
import http from "../../http-common";

export default {
    name: 'NoticeDetail',
    props: ["no"],
    data() {
        return {
            loading: true,
            errored: false,
            notice: {}
        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
      show_init: function() {
        http
          .get("/notice/" + this.no)
          .then(response => (this.notice = response.data))
          .catch(() => {
            this.errored = true;
          })
          .finally(() => (this.loading = false));
      },
      deleteNotice: function() {
        http
          .delete("/notice/" + this.no)
          .then((success) => {
            console.log(success);
            this.$router.push("/notice")
            })
      },
      modifyNotice: function() {
        this.$router.push("/notice/modify/" + this.no);
      },
      Notice: function() {
        this.$router.push("/notice");
      }
    },
    mounted() {
      this.show_init();
    }
}
</script>

<style scoped>
button {
  margin: 10px;
}
pre {
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  white-space: pre-wrap;
  word-wrap: break-word;
}
#top {
  font-weight: 500;
  color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
