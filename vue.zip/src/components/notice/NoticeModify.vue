<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">공지사항</h2>

                        <table style="width: 100%;" class="table table-striped table-hover">
                            <tbody id = "searchResult">
                                <tr>
                                    <th style="width:20%; text-align:center;">제목</th>
                                    <th style="width:73%; text-align:center;"><input type="text" class="form-control" style="width:100%" v-model="notice.title"></th>
                                    <th style="width:7%; text-align:center;"><input type="checkbox" id="top" class="form-control" v-model="notice.top" true-value="1" false-value="0"></th>
                                </tr>
                                <tr>
                                    <th style="width:20%; text-align:center;">내용</th>
                                    <th colspan='2' style="width:80%;"><textarea style="width:100%; height:300px" class="form-control" v-model="notice.notice_describe"></textarea></th>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <div style="text-align: center;">
                            <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button" v-on:click="modifyNotice">수정 완료</button>
                            <router-link class="nav-link" to="/notice" style="display:inline-block;">
                              <button id="allowEdit" class="btn btn-primary font-weight-bold" type="button">취소</button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import http from "../../http-common";

export default {
    name: 'NoticeModify',
    props: ["no"],
    data() {
        return {
            loading: true,
            errored: false,
            notice: {}
        };
    },
    methods: {
      show_init: function() {
        http
          .get("/notice/" + this.no)
          .then(response => (this.notice = response.data))
          .catch(() => {
            this.errored = true;
          })
          .finally(() => (this.loading = false));
      },
      modifyNotice: function() {
        http
          .put("/notice/", {
            title: this.notice.title,
            notice_describe: this.notice.notice_describe,
            top: this.notice.top,
            no: this.no
          })
          .then((success) => {
            console.log(success);
            this.$router.push("/notice")
            })
      }
    },
    mounted() {
        if(!this.getisLogin){
            alert("공지 수정 페이지는 관리자만 사용 가능합니다.");         
            this.$router.go(-1);
        } else {
            this.show_init();
        }
    }
}
</script>

<style scoped>
pre {
  white-space: -moz-pre-wrap;
  white-space: -pre-wrap;
  white-space: -o-pre-wrap;
  white-space: pre-wrap;
  word-wrap: break-word;
}
#top {
  font-weight: 500;
  color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
