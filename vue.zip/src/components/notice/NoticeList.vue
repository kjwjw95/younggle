<template>
    <div id="tab" class="container-fluid">
        <div class="d-flex align-items-center py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 mx-auto">
                        <h2 class="login-heading mb-4">공지사항</h2>

                        <table style="width: 100%" class="table table-hover">
                            <thead>
                                <tr>
                                    <th style="width:10%; text-align:center;">번호</th>
                                    <th style="width:75%; text-align:center;">제목</th>
                                    <th style="width:15%; text-align:center;">작성일시</th>
                                </tr>
                            </thead>
                            <tbody style="background: #e9e9e9" v-if="(topNotice != null)" id = "searchResult">
                                <tr id="top" v-for="(notice,index) in topNotice" class="topNotice" data-status="active" v-bind:key="index">
                                    <td style="text-align:center;" id="no">{{notice.no}}</td>
                                    <td id="title" v-on:click="detail(notice.no)">{{notice.title}}</td>
                                    <td style="text-align:center;" id="date">{{notice.writetime}}</td>
                                </tr>
                            </tbody>
                            <tbody v-if="defaultNotice != null" id = "searchResult">
                                <tr v-for="(notice,index) in defaultNotice" class="defaultNotice" data-status="active" v-bind:key="index">
                                    <td style="text-align:center;" id="no">{{notice.no}}</td>
                                    <td id="title" v-on:click="detail(notice.no)">{{notice.title}}</td>
                                    <td style="text-align:center;" id="date">{{notice.writetime}}</td>
                                </tr>
                            </tbody>
                        </table>
                        <br>
                        <div class="nav-link" style="text-align: center;">
                            <router-link to="/notice/write">
                            <!-- 어드민 설정 -->
                                <button v-if="getUserId=='1541781079'" id="allowEdit" class="btn btn-primary font-weight-bold"
                                    type="button">글쓰기</button>
                            </router-link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import { mapGetters } from "vuex";
import http from "../../http-common";

export default {
    name: 'Notice',
    data() {
        return {
            loading: true,
            errored: false,
            topNotice: [],
            defaultNotice: [],
            pageLimit : 10,
            pageOffet : 0

        };
    },
    computed: {
        ...mapGetters(["getAccessToken", "getUserId", "getUserName", "getImage","getisLogin"]),
    },
    methods: {
        detail: function(no) {
            this.$router.push("/notice/" + no);
        },
        initComponent(){
      http
        .get('/notice/pagelink',{
            params: { limit: this.pageLimit, offset: `${this.$route.query.no - this.pageLimit}`}
          })
        .then(({ data }) => {
          this.defaultNotice = data
        })
        .catch(() => {
          alert('에러가 발생했습니다.');
        });
    }
    },
    created() {
        http
          .get("/notice/topNotice")
          .then(response => (this.topNotice = response.data))
          .catch(() => {
            this.errored = true;
          })
          .finally(() => (this.loading = false));
          this.initComponent();
        // http
        //   .get("/notice/defaultNotice")
        //   .then(response => (this.defaultNotice = response.data))
        //   .catch(() => {
        //     this.errored = true;
        //   })
        //   .finally(() => (this.loading = false));
    },
  watch: {
    '$route.query': function(){
      this.initComponent();
    }
  }
}
</script>

<style scoped>
#top {
    font-weight: 500;
    color: blue;
}
h3 {
  margin: 40px 0 0;
}
h5 {
  font-weight: 550;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
