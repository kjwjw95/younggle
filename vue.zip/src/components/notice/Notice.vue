<template>
  <div class="about">
    <router-view/>
    <page-link/>
  </div>
</template>

<script>
// @ is an alias to /src
import PageLink from "./PageLink.vue";

export default {
  name: "Notice",
  components: {
    PageLink
  }
};
</script>