package com.ssafy.happyhouse.mapper;

public class Snippet {
	public static void main(String[] args) {
	}
}

