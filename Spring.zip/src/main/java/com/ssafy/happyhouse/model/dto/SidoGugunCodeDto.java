package com.ssafy.happyhouse.model.dto;

public class SidoGugunCodeDto {

	private String sido_Code;
	private String sido_Name;
	private String gugun_Code;
	private String gugun_Name;
	
	public String getSido_Code() {
		return sido_Code;
	}
	public void setSido_Code(String sido_Code) {
		this.sido_Code = sido_Code;
	}
	public String getSido_Name() {
		return sido_Name;
	}
	public void setSido_Name(String sido_Name) {
		this.sido_Name = sido_Name;
	}
	public String getGugun_Code() {
		return gugun_Code;
	}
	public void setGugun_Code(String gugun_Code) {
		this.gugun_Code = gugun_Code;
	}
	public String getGugun_Name() {
		return gugun_Name;
	}
	public void setGugun_Name(String gugun_Name) {
		this.gugun_Name = gugun_Name;
	}

}
